document.addEventListener('DOMContentLoaded', function() {
    const config = {
        width: 700,
        height: 450,
        margin: 30,
        innerRadius: 120,
        colorScheme: ["#7b2cbf", "#f46d43", "#66bd63", "#d73027"],
        minAngle: 0.03
    };

    const radius = Math.min(config.width, config.height) / 2 - config.margin;

    const svg = d3.select('.chart')
        .attr('width', config.width)
        .attr('height', config.height);

    const canvas = svg.append('g')
        .attr('transform', `translate(${radius + config.margin},${config.height / 2})`);

    const pieMaker = d3.pie()
        .sort(null)
        .padAngle(0.005)
        .value(d => d.value)
        .startAngle(0)
        .endAngle(2 * Math.PI);

    const sliceArc = d3.arc()
        .innerRadius(config.innerRadius)
        .outerRadius(radius);

    const palette = d3.scaleOrdinal(config.colorScheme);

    const tooltip = d3.select("body")
        .append("div")
        .style("position", "absolute")
        .style("background", "white")
        .style("padding", "8px")
        .style("border", "1px solid #ccc")
        .style("border-radius", "6px")
        .style("box-shadow", "2px 2px 5px rgba(0,0,0,0.3)")
        .style("pointer-events", "none")
        .style("font-size", "13px")
        .style("opacity", 0);

    d3.csv("jobs_in_data.csv").then(raw => {
        const grouped = d3.rollups(raw, v => v.length, d => d.employment_type);
        const formatted = grouped.map(([key, value]) => ({ category: key, value }));

        fixSmallSlices(formatted);
        renderPie(formatted);
        renderLegend(formatted);
    }).catch(error => console.error("Failed to load data:", error));

    function fixSmallSlices(dataset) {
        const total = d3.sum(dataset, d => d.value);
        const minValue = config.minAngle * total / (2 * Math.PI);
        dataset.forEach(d => {
            if (d.value < minValue) d.value = minValue;
        });
    }

    function renderPie(dataset) {
        const arcs = pieMaker(dataset);

        canvas.selectAll('path.slice')
            .data(arcs)
            .join('path')
            .attr('class', 'slice')
            .attr('fill', d => palette(d.data.category))
            .attr('stroke', 'white')
            .attr('stroke-width', '2px')
            .transition()
            .duration(1200)
            .attrTween('d', function(d) {
                const i = d3.interpolate({ startAngle: d.startAngle, endAngle: d.startAngle }, d);
                return function(t) { return sliceArc(i(t)); };
            });

        canvas.selectAll('path.slice')
            .on('mouseover', function(event, d) {
                tooltip.transition().duration(200).style("opacity", 0.9);
                tooltip.html(`<strong>${d.data.category}</strong><br/>Count: ${d.data.value}`)
                    .style("left", (event.pageX + 15) + "px")
                    .style("top", (event.pageY - 30) + "px");
            })
            .on('mousemove', event => {
                tooltip.style("left", (event.pageX + 15) + "px")
                    .style("top", (event.pageY - 30) + "px");
            })
            .on('mouseout', () => {
                tooltip.transition().duration(400).style("opacity", 0);
            });
    }

    function renderLegend(dataset) {
        const legendZone = svg.append('g')
            .attr('transform', `translate(${radius * 2 + 50}, ${config.margin + 30})`);

        const entry = legendZone.selectAll('.legend-entry')
            .data(dataset)
            .join('g')
            .attr('class', 'legend-entry')
            .attr('transform', (d, i) => `translate(0, ${i * 25})`);

        entry.append('rect')
            .attr('x', 0)
            .attr('width', 16)
            .attr('height', 16)
            .attr('fill', d => palette(d.category));

        entry.append('text')
            .attr('x', 24)
            .attr('y', 8)
            .attr('dy', '0.35em')
            .style('text-anchor', 'start')
            .style('font-size', '13px')
            .text(d => d.category);
    }
});
