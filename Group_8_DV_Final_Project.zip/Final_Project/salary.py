import pandas as pd
import os

# Define file paths
input_file = 'jobs_in_data.csv'
output_dir = 'salary comp'

# Ensure output directory exists
os.makedirs(output_dir, exist_ok=True)

# Read the dataset
df = pd.read_csv(input_file)

# Display basic dataset info
print(df.head())
print(list(df.columns))

# Function to compute average salary for a given feature
def compute_average_salary(df, group_column, category_name, output_filename):
    result = (
        df.groupby(group_column)['salary']
        .mean()
        .reset_index()
        .rename(columns={group_column: 'label', 'salary': 'average_salary'})
    )
    result['category'] = category_name
    result.to_csv(os.path.join(output_dir, output_filename), index=False)

# Define aggregation settings
aggregation_tasks = [
    ('company_size', 'CompanySize', 'sal_company_size_data.csv'),
    ('work_setting', 'WorkSetting', 'sal_work_setting_data.csv'),
    ('job_title', 'JobTitle', 'sal_job_title_data.csv'),
    ('experience_level', 'ExperienceLevel', 'sal_experience_level_data.csv')
]

# Perform aggregation and export results
for column, category, filename in aggregation_tasks:
    compute_average_salary(df, column, category, filename)