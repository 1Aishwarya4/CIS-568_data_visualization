(function() {
    const config = {
        margin: { top: 80, right: 200, bottom: 220, left: 90 }, // increased bottom margin for rotated labels
        width: 1000,
        height: 650,
        barPadding: 0.08,
        colorScheme: [
            "#8da0cb", "#fc8d62", "#66c2a5", "#e78ac3", "#a6d854",
            "#ffd92f", "#e5c494", "#b3b3b3", "#b2df8a", "#cab2d6"
        ],
        transitionDuration: 1000
    };

    const fullWidth = config.width;
    const fullHeight = config.height;
    const plotWidth = fullWidth - config.margin.left - config.margin.right;
    const plotHeight = fullHeight - config.margin.top - config.margin.bottom;

    const svgCanvas = d3.select("#bargraphSVG")
        .attr("width", fullWidth)
        .attr("height", fullHeight);

    const chartArea = svgCanvas.append("g")
        .attr("transform", `translate(${config.margin.left},${config.margin.top})`);

    const tooltip = d3.select("body")
        .append("div")
        .attr("class", "tooltip-box")
        .style("opacity", 0);

    const buildColorScale = () => d3.scaleOrdinal()
        .domain(d3.range(10))
        .range(config.colorScheme);

    const processRawData = (entries) => {
        const salaryMap = entries.reduce((acc, curr) => {
            const category = curr.job_category;
            const salary = +curr.salary_in_usd;
            if (!acc.has(category)) acc.set(category, []);
            acc.get(category).push(salary);
            return acc;
        }, new Map());

        return Array.from(salaryMap, ([category, salaries]) => ({
            category,
            avgSalary: d3.mean(salaries)
        })).sort((a, b) => d3.descending(a.avgSalary, b.avgSalary));
    };

    const setupXScale = (dataset) => d3.scaleBand()
        .domain(dataset.map(d => d.category))
        .range([0, plotWidth])
        .padding(config.barPadding);

    const setupYScale = (dataset) => d3.scaleLinear()
        .domain([0, d3.max(dataset, d => d.avgSalary)]).nice()
        .range([plotHeight, 0]);

    const drawBars = (dataset, x, y, color) => {
        chartArea.selectAll(".bar-rect")
            .data(dataset)
            .enter()
            .append("rect")
            .attr("class", "bar-rect")
            .attr("x", d => x(d.category))
            .attr("width", x.bandwidth())
            .attr("y", plotHeight)
            .attr("height", 0)
            .attr("fill", (d, i) => color(i))
            .transition()
            .duration(config.transitionDuration)
            .attr("y", d => y(d.avgSalary))
            .attr("height", d => plotHeight - y(d.avgSalary));
    };

    const enableInteractivity = () => {
        chartArea.selectAll(".bar-rect")
            .on("mouseover", (event, d) => {
                tooltip.transition()
                    .duration(200)
                    .style("opacity", .95);
                tooltip.html(`<strong>${d.category}</strong><br/>$${d.avgSalary.toFixed(2)}`)
                    .style("left", (event.pageX + 15) + "px")
                    .style("top", (event.pageY - 30) + "px");
            })
            .on("mouseout", () => {
                tooltip.transition()
                    .duration(300)
                    .style("opacity", 0);
            });
    };

    const addAxes = (x, y) => {
        const xAxisGroup = chartArea.append("g")
            .attr("transform", `translate(0,${plotHeight})`) // ✅ Corrected: only plotHeight
            .call(d3.axisBottom(x));

        xAxisGroup.selectAll("text")
            .style("text-anchor", "end")
            .attr("dx", "-0.8em")
            .attr("dy", "0.25em") // ✅ Slightly move label down
            .attr("transform", "rotate(-40)") // ✅ Tilt labels
            .style("font-size", "12px")
            .style("font-weight", "bold");

        chartArea.append("g")
            .call(d3.axisLeft(y).tickFormat(d3.format("$.2s")));
    };

    const addChartLabels = () => {
        chartArea.append("text")
            .attr("transform", "rotate(-90)")
            .attr("y", -55)
            .attr("x", -plotHeight / 2)
            .attr("text-anchor", "middle")
            .style("font-size", "14px")
            .text("Average Salary (USD)");

        svgCanvas.append("text")
            .attr("x", fullWidth / 2)
            .attr("y", 30)
            .attr("text-anchor", "middle")
            .style("font-size", "26px")
            .style("font-weight", "bold")
            .text("Average Pay by Employment Type");
    };

    const launchChart = (rawInput) => {
        const processed = processRawData(rawInput);
        const x = setupXScale(processed);
        const y = setupYScale(processed);
        const color = buildColorScale();

        drawBars(processed, x, y, color);
        enableInteractivity();
        addAxes(x, y);
        addChartLabels();
    };

    d3.csv("jobs_in_data.csv").then(launchChart);
})();
