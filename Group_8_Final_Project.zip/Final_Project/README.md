# Data Science Job Market Analysis: Salary Trends and Insights

## Group Members:
- Aishwarya Kajinamane Shyamasundar (02198465)
- Suvidha Sharma (02196543)
- Druthi Sathish (02179293)

---

## Project Description:

This project presents a dashboard-style interactive visualization that explores various aspects of the data science job market globally.  
It focuses on salary distribution, employment trends, experience-level salary progression, and employment type breakdown across different countries and job categories.

We utilized D3.js (v7) for building multiple interconnected visualizations, all fully interactive.

---

## How to Run the Project:

1. Unzip the `Final_Project.zip` file provided.
2. Open the main file `index.html` in any modern browser (Google Chrome, Firefox, Edge).
3. Ensure that the CSV dataset file (`jobs_in_data.csv`) is located in the same folder as `index.html`.
4. No installation, Node.js, or backend server required — it runs directly on the browser.

> If you face CORS (Cross-Origin Resource Sharing) issues while opening locally,  
> Option 1: Right-click `index.html` → "Open With" → Browser  
> Option 2: Use VS Code + Live Server extension to run it easily.

---

## How to Read the Visualizations:

### 1. World Salary Map
- Purpose: Explore average salaries by country.
- Encoding: Darker shades → Higher average salary.  
- Interaction: Buttons for 2020–2023 to filter by year.

### 2. Employment Trends Line Chart (Histogram.js)
- Purpose: Shows the number of jobs in key fields (Data Engineering, Cloud, AI, etc.) across 2020-2023.
- X-Axis: Years (2020–2023)
- Y-Axis: Number of employment opportunities
- Encoding: Colored lines for different job categories.
- Interaction: Lines highlight on hover with tooltips.

### 3. Salary Comparison Bar Graph (Bargraph.js)
- Purpose: Compare average salaries across different data science roles.
- X-Axis: Job categories (Machine Learning, BI, Cloud, etc.)
- Y-Axis: Average salary (in USD)
- Encoding: Color-coded bars.
- Interaction: Bars show salary tooltip on hover.

### 4. Salary vs Experience Level Parallel Plot (ParallelPlot.js)
- Purpose: Track how salary progresses from Entry-level → Executive roles.
- Axis 1: Work Year  
- Axis 2: Salary (USD)
- Encoding: Colored lines based on Experience Level (Entry, Mid, Senior, Executive).
- Interaction: Lines highlight slightly on hover.

### 5. Employment Type Distribution Doughnut Chart (Piechart.js)
- Purpose: Breakdown of employment types (Full-time, Part-time, Contract, Freelance).
- Encoding: Pie slices color-coded (Violet, Orange, Green, Red).
- Interaction: Slice tooltip shows employment type and count on hover.

---

## Screenshots:

We have added the screenshots of the below in the screenshots folder
> Map visualization
> Line graph
> Bar graph
> Pie chart

---

## Hosting Link:

- GitHub Link - 

---

## Framework/Libs Used:

- D3.js v7 (loaded via CDN)
- Vanilla HTML + CSS
- Dataset: `jobs_in_data.csv`
