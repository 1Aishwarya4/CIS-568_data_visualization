document.addEventListener('DOMContentLoaded', startChart);

async function startChart() {
    const rawDataset = await loadDataset("jobs_in_data.csv");
    const groupedData = transformData(rawDataset);
    const config = buildChartCanvas();
    
    createChartAxes(config);
    plotTrendLines(groupedData, config);
    drawChartLegend(config);
}

async function loadDataset(filepath) {
    const csvData = await d3.csv(filepath);
    return csvData.map(row => ({
        year: +row.work_year,
        category: row.job_category,
        salary: +row.salary_in_usd
    }));
}

function transformData(data) {
    const categoryYearMap = {};

    for (const entry of data) {
        if (!categoryYearMap[entry.category]) {
            categoryYearMap[entry.category] = {};
        }
        if (!categoryYearMap[entry.category][entry.year]) {
            categoryYearMap[entry.category][entry.year] = [];
        }
        categoryYearMap[entry.category][entry.year].push(entry.salary);
    }

    const averagedData = {};
    for (const category in categoryYearMap) {
        averagedData[category] = Object.entries(categoryYearMap[category]).map(([year, salaries]) => ({
            year: +year,
            salary: d3.mean(salaries)
        }));
    }
    return averagedData;
}

function buildChartCanvas() {
    const margin = { top: 20, right: 300, bottom: 40, left: 60 }; 
    const fullWidth = 1100; 
    const fullHeight = 500;

    const svgBase = d3.select("#my_dataviz")
        .append("svg")
        .attr("width", fullWidth)
        .attr("height", fullHeight);

    const plotGroup = svgBase.append("g")
        .attr("transform", `translate(${margin.left},${margin.top})`);

    const xScale = d3.scaleLinear()
        .domain([2020, 2023])
        .range([0, fullWidth - margin.left - margin.right]);

    const yScale = d3.scaleLinear()
        .domain([0, 250000])
        .range([fullHeight - margin.top - margin.bottom, 0]);

    const colorScale = d3.scaleOrdinal(d3.schemeTableau10);

    const hoverGroup = svgBase.append("g").style("display", "none");

    hoverGroup.append("rect")
        .attr("width", 160)
        .attr("height", 50)
        .attr("fill", "#d3d3d3")
        .style("opacity", 0.9);

    hoverGroup.append("text")
        .attr("x", 10)
        .attr("y", 25)
        .style("font-family", "Arial")
        .style("font-size", "13px");

    return {svg: svgBase, chart: plotGroup, xScale, yScale, colorScale, hoverGroup, margin, fullWidth, fullHeight};
}

function createChartAxes(cfg) {
    cfg.chart.append("g")
        .attr("transform", `translate(0,${cfg.fullHeight - cfg.margin.top - cfg.margin.bottom})`)
        .call(d3.axisBottom(cfg.xScale).ticks(4).tickFormat(d3.format("d")));

    cfg.chart.append("g")
        .call(d3.axisLeft(cfg.yScale));
}

function plotTrendLines(grouped, cfg) {
    const lineMaker = d3.line()
        .x(d => cfg.xScale(d.year))
        .y(d => cfg.yScale(d.salary))
        .curve(d3.curveMonotoneX);

    for (const category of Object.keys(grouped)) {
        const lineData = grouped[category];

        cfg.chart.append("path")
            .datum(lineData)
            .attr("fill", "none")
            .attr("stroke", cfg.colorScale(category))
            .attr("stroke-width", 3)
            .attr("d", lineMaker)
            .on("mouseover", (event, data) => {
                const mouseX = cfg.xScale.invert(d3.pointer(event)[0]);
                const nearest = data.reduce((prev, curr) =>
                    Math.abs(prev.year - mouseX) < Math.abs(curr.year - mouseX) ? prev : curr
                );

                cfg.hoverGroup.style("display", null)
                    .attr("transform", `translate(${event.offsetX + 10},${event.offsetY - 30})`);
                cfg.hoverGroup.select("text")
                    .text(`Cat: ${category}  Yr: ${nearest.year}  $${Math.round(nearest.salary)}`);
            })
            .on("mouseout", () => {
                cfg.hoverGroup.style("display", "none");
            });
    }
}

function drawChartLegend(cfg) {
    const catArray = cfg.colorScale.domain();

    const legends = cfg.svg.append("g") 
        .attr("transform", `translate(${cfg.fullWidth - cfg.margin.right + 30},${cfg.margin.top})`) // Push legend outside
        .selectAll(".legend")
        .data(catArray)
        .enter()
        .append("g")
        .attr("class", "legend")
        .attr("transform", (d, i) => `translate(0, ${i * 25})`); 

    legends.append("rect")
        .attr("x", 0)
        .attr("width", 15)
        .attr("height", 15)
        .style("fill", cfg.colorScale);

    legends.append("text")
        .attr("x", 25) 
        .attr("y", 12)
        .attr("dy", ".1em")
        .style("font-family", "Arial")
        .style("font-size", "12px")
        .text(d => d);
}
