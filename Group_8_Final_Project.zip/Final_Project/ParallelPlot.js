const setup = {
    margins: { top: 30, right: 150, bottom: 10, left: 0 },
    fullWidth: 810,
    fullHeight: 490,
    experienceLabels: ["Entry-Level", "Executive", "Mid-Level", "Senior", "Other"],
    experienceCorrection: {
        "entry-level": "Entry-Level",
        "executive": "Executive",
        "mid-level": "Mid-Level",
        "senior": "Senior"
    }
};

setup.innerWidth = setup.fullWidth - setup.margins.left - setup.margins.right;
setup.innerHeight = setup.fullHeight - setup.margins.top - setup.margins.bottom;

const base = d3.select("#parallelPlot svg")
    .attr("width", setup.fullWidth)
    .attr("height", setup.fullHeight)
    .append("g")
    .attr("transform", `translate(${setup.margins.left},${setup.margins.top})`);

const colorPalette = d3.scaleOrdinal()
    .domain(setup.experienceLabels)
    .range(d3.schemeTableau10);

const tooltip = d3.select("body")
    .append("div")
    .attr("class", "tooltip-box")
    .style("opacity", 0)
    .style("position", "absolute")
    .style("background", "white")
    .style("padding", "8px")
    .style("border", "1px solid gray")
    .style("border-radius", "4px")
    .style("pointer-events", "none");

const cleaner = level => {
    const cleaned = level.trim().toLowerCase().replace(/[^a-z\\-]/g, "");
    return setup.experienceCorrection[cleaned] || "Other";
};

function createYScales(dataList, metrics) {
    const scales = {};
    metrics.forEach(metric => {
        scales[metric] = d3.scaleLinear()
            .domain(d3.extent(dataList, d => +d[metric]))
            .nice()
            .range([setup.innerHeight, 0]);
    });
    return scales;
}

function createXScale(metrics) {
    return d3.scalePoint()
        .domain(metrics)
        .range([0, setup.innerWidth])
        .padding(0.5);
}

const drawer = {
    pathBuilder: function(entry, metrics, xFunc, yFuncs) {
        return d3.line()(metrics.map(m => [xFunc(m), yFuncs[m](entry[m])]));
    },

    plotLines: function(canvas, entries, metrics, xFunc, yFuncs, colorizer) {
        canvas.selectAll(".polyline")
            .data(entries)
            .enter()
            .append("path")
            .attr("class", "polyline")
            .attr("d", d => this.pathBuilder(d, metrics, xFunc, yFuncs))
            .attr("stroke", d => colorizer(d.experience_level))
            .attr("fill", "none")
            .attr("stroke-width", 1.5)
            .attr("opacity", 0.6)
            .on("mouseover", function(event, d) {
                d3.selectAll(".polyline").transition().style("opacity", 0.1);
                d3.select(this)
                    .transition()
                    .duration(200)
                    .style("stroke-width", 3)
                    .style("opacity", 1);

                tooltip.transition()
                    .duration(200)
                    .style("opacity", 1);
                tooltip.html(
                    `<strong>Experience:</strong> ${d.experience_level}<br/>
                     <strong>Work Year:</strong> ${d.work_year}<br/>
                     <strong>Salary:</strong> $${(+d.salary_in_usd).toLocaleString()}`
                )
                .style("left", (event.pageX + 15) + "px")
                .style("top", (event.pageY - 30) + "px");
            })
            .on("mousemove", function(event) {
                tooltip.style("left", (event.pageX + 15) + "px")
                       .style("top", (event.pageY - 30) + "px");
            })
            .on("mouseout", function() {
                d3.selectAll(".polyline").transition().style("opacity", 0.6).style("stroke-width", 1.5);
                tooltip.transition()
                    .duration(300)
                    .style("opacity", 0);
            });
    },

    addAxes: function(canvas, metrics, xFunc, yFuncs) {
        metrics.forEach(attribute => {
            const axisG = canvas.append("g")
                .attr("transform", `translate(${xFunc(attribute)},0)`)
                .attr("class", "attribute-axis");

            const axis = d3.axisLeft(yFuncs[attribute]);
            if (attribute === "work_year") axis.tickFormat(d3.format("d"));
            
            axisG.call(axis);

            axisG.append("text")
                .attr("y", -9)
                .attr("text-anchor", "middle")
                .text(attribute)
                .style("fill", "black");

            if (attribute === "salary_in_usd") {
                axisG.selectAll("text")
                    .attr("transform", "translate(15,0)")
                    .style("text-anchor", "start");
            }
        });
    },

    buildLegend: function(canvas, colorizer) {
        const group = canvas.selectAll(".legend-box")
            .data(colorizer.domain())
            .enter()
            .append("g")
            .attr("class", "legend-box")
            .attr("transform", (d, i) => `translate(0,${i * 20})`);

        group.append("rect")
            .attr("x", setup.innerWidth - 30)
            .attr("width", 18)
            .attr("height", 18)
            .style("fill", colorizer);

        group.append("text")
            .attr("x", setup.innerWidth)
            .attr("y", 9)
            .attr("dy", ".35em")
            .text(d => d)
            .style("text-anchor", "start");
    }
};

async function orchestrateParallelCoordinates() {
    try {
        const jobData = await d3.csv("jobs_in_data.csv");

        jobData.forEach(row => {
            row.experience_level = cleaner(row.experience_level);
        });

        const metrics = ["work_year", "salary_in_usd"];
        const yScales = createYScales(jobData, metrics);
        const xScale = createXScale(metrics);

        drawer.plotLines(base, jobData, metrics, xScale, yScales, colorPalette);
        drawer.addAxes(base, metrics, xScale, yScales);
        drawer.buildLegend(base, colorPalette);

    } catch (error) {
        console.error("Data Processing Error:", error);
    }
}

orchestrateParallelCoordinates();
