document.addEventListener('DOMContentLoaded', initializeApp);

async function initializeApp() {
    const mapContainer = d3.select("#mapSVG");
    const mapWidth = +mapContainer.attr("width");
    const mapHeight = +mapContainer.attr("height");

    const mapProjection = d3.geoMercator()
        .scale(175)
        .translate([mapWidth / 2, mapHeight / 2]);

    const geoPath = d3.geoPath().projection(mapProjection);
    setupZoom(mapContainer, mapProjection, geoPath);

    const tooltip = setupTooltip();

    const [worldGeoData, jobData] = await loadData();
    const formattedData = processJobData(jobData);

    const colorScale = setupColorScale(formattedData);

    setupYearButtons(worldGeoData, formattedData, mapContainer, geoPath, colorScale, tooltip);
    drawInitialMap(worldGeoData, formattedData, mapContainer, geoPath, colorScale, tooltip);
}

function setupZoom(svgElement, projection, pathGen) {
    const zoom = d3.zoom()
        .scaleExtent([1, 8])
        .on("zoom", event => {
            const { transform } = event;
            projection
                .scale(150 * transform.k)
                .translate([transform.x, transform.y]);

            svgElement.selectAll("path").attr("d", pathGen);
            svgElement.selectAll("text")
                .attr("transform", d => {
                    const center = pathGen.centroid(d);
                    return `translate(${center[0]}, ${center[1]}) scale(${transform.k})`;
                })
                .attr("font-size", `${8 / transform.k}px`);
        });

    svgElement.call(zoom);
}

function setupTooltip() {
    let tt = d3.select("#tooltip");
    if (tt.empty()) {
        tt = d3.select("body").append("div")
            .attr("id", "tooltip")
            .attr("class", "tooltip")
            .style("display", "none");
    }
    return tt;
}

async function loadData() {
    const geoJson = d3.json('https://raw.githubusercontent.com/johan/world.geo.json/master/countries.geo.json');
    const csvData = d3.csv('jobs_in_data.csv');
    return Promise.all([geoJson, csvData]);
}

function processJobData(rawData) {
    const countryRename = { "United States": "United States of America" };
    return rawData.map(d => ({
        ...d,
        company_location: countryRename[d.company_location] || d.company_location
    }));
}

function setupColorScale(data) {
    return d3.scaleSequential()
        .domain([0, d3.max(data, d => +d.salary_in_usd) * 2])
        .interpolator(d3.interpolateBlues);
}

function drawInitialMap(worldData, salaryData, svg, pathGen, colorScale, tooltip) {
    renderMap(worldData, salaryData, svg, pathGen, colorScale, tooltip);
}

function renderMap(worldData, salaryDataset, svgElement, pathGenerator, colorScaler, tooltipDiv) {
    svgElement.selectAll("path")
        .data(worldData.features)
        .join("path")
        .attr("d", pathGenerator)
        .attr("fill", feature => {
            const matchData = salaryDataset.filter(d => d.company_location === feature.properties.name);
            const meanSalary = d3.mean(matchData, d => +d.salary_in_usd);
            return colorScaler(meanSalary || 0);
        })
        .on("mouseover", (event, feature) => showTooltip(event, feature, salaryDataset, tooltipDiv))
        .on("mousemove", event => moveTooltip(event, tooltipDiv))
        .on("mouseout", () => hideTooltip(tooltipDiv));

    svgElement.selectAll("text")
        .data(worldData.features.filter(f => salaryDataset.some(d => d.company_location === f.properties.name)))
        .join("text")
        .attr("text-anchor", "middle")
        .attr("fill", "black")
        .attr("font-size", "8px")
        .attr("transform", d => {
            const center = pathGenerator.centroid(d);
            return `translate(${center[0]},${center[1]})`;
        })
        .text(d => d.properties.name);
}

function showTooltip(event, feature, data, tooltipDiv) {
    const related = data.filter(d => d.company_location === feature.properties.name);
    const avgSalary = d3.mean(related, d => +d.salary_in_usd);

    tooltipDiv.style("display", "block")
        .html(`<strong>${feature.properties.name}</strong><br>Average Salary: $${avgSalary ? avgSalary.toFixed(2) : 'N/A'}`)
        .style("left", (event.pageX + 10) + "px")
        .style("top", (event.pageY - 10) + "px");
}

function moveTooltip(event, tooltipDiv) {
    tooltipDiv.style("left", (event.pageX + 10) + "px")
              .style("top", (event.pageY - 10) + "px");
}

function hideTooltip(tooltipDiv) {
    tooltipDiv.style("display", "none");
}

function setupYearButtons(worldGeo, jobData, svgMap, geoPathMaker, colorScheme, ttBox) {
    const years = ["2020", "2021", "2022", "2023"];
    years.forEach(year => {
        d3.select(`#year${year}`)
            .on("click", () => {
                const yearFiltered = jobData.filter(d => d.work_year.toString() === year);
                renderMap(worldGeo, yearFiltered, svgMap, geoPathMaker, colorScheme, ttBox);
            });
    });
}